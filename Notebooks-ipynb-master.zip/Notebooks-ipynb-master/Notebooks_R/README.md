# Notebooks-ipynb
##### Local onde meus projetos em R serão armazenados(EM ANDAMENTO)
***

## Observações:
###### para pré-visualizar os projetos basta clicar em seus respectivos arquivos .ipynb, os códigos .R dos projetos estarão disponibilizados separadamente.
###### Os datasets(.csv) de cada projeto estão disponíveis em seus respectivos diretórios

