## Análise exploratória de um dataset de uma loja virtual fictícia, com o intuito de saber qual sistema operacional é mais utilizado pelos clientes, qual o que gera mais lucros, entre outras coisas.


### Obs: Preview do projeto clicando no arquivo .ipynb

