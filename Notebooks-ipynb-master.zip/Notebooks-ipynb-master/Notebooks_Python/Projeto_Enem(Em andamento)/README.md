## Projeto em **andamento**.
### Obs: Preview do projeto clicando no arquivo .ipynb
#### Este projeto tem como objetivo fazer uma análise **detalhada** de uma amostra de um dataset do enem 2019
