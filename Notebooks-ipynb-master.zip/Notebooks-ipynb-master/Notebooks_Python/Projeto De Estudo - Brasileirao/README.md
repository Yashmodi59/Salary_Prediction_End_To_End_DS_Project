# Projeto de estudo

## Será feita uma análise do conjunto de dados do campeoanto brasileiro desde a temporada 2000 ate o ano de 2019, estudando o histórico do Clube Sociedade Esportiva Palmeiras afim de extrair informações relevantes.
### Obs: Preview do projeto clicando no arquivo .ipynb

## Informações adicionais:
Lembrando que o campeonato brasileiro é um campeonato de pontos corridos, com 38 rodadas, onde uma vitória soma 3 pontos, empate soma 1, e derrota 0 pontos, e o time que conseguir maior quantidade de pontos ao final do campeonato vence, tendo critérios a parte em caso de empate de pontos, dito isso, vamos para a análise.
