# Análise exploratória de um dataset da PNAD de 2012, a fim de extrair informações relevantes.


## Informações adicionais:


**O que é PNAD?**
A Pesquisa Nacional por Amostra de Domicílios (PNAD) era uma pesquisa anual realizada pelo IBGE nos domicílios brasileiros para apurar características gerais da população, incluindo dados de educação, trabalho, rendimento e habitação, além de levantar, com periodicidade variável, outros temas, de acordo com as necessidades de informação para o país.

A pesquisa foi encerrada em 2016 e substituída, com metodologia atualizada, pela Pesquisa Nacional por Amostra de Domicílios Contínua – PNAD Contínua.
