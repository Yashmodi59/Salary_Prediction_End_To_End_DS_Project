## Projeto de predição de preços de casas
### Obs: Preview do projeto clicando no arquivo .ipynb


#### Este projeto contem dados **fictícios** de um dataset com informações de imóveis
# Informações adicionais:
## Modelos utilizados: 
##### Linear Regression
##### Gradient Boosting
##### Random Forest
##### Decision Tree

