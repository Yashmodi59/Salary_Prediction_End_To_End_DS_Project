# Análise exploratória de um dataset de uma empresa **fictícia** de publicidade
### Obs: Preview do projeto clicando no arquivo .ipynb

## Informações adicionais:
# modelo utilizado:
#### Logistic Regression
#### Random Forest
#### Gradient Boosting
#### SVC
#### KNN
