## Projeto titanic
### Obs: Preview do projeto clicando no arquivo .ipynb

#### Este projeto faz uma análise exploratória **detalhada** assim como minera os dados do dataset de treino e teste do titanic, afim de executar variados modelos preditivos para saber informações sobre os possiveis sobreviventes faltantes.

# Informações adicionais:
## Modelos utilizado: 
#### Logistic Regression
#### Linear Regression
#### KNN
#### ExtraTreesClassifier
#### GradientBoostingClassifier
#### AdaBoostClassifier
#### SVC
#### GaussianNB
#### Perceptron
#### LinearSVC
#### SGDClassifier
#### DecisionTreeClassifier
#### RandomForestClassifier

