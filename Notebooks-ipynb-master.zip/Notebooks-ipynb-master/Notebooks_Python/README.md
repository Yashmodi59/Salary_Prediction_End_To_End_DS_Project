# Notebooks-ipynb
##### Local onde meus Notebooks e projetos em Python estarão salvos
***
## Observações:
###### para pré-visualizar os projetos basta clicar em seus respectivos arquivos .ipynb
###### Os datasets(.csv) de cada projeto estão disponíveis em seus respectivos diretórios

