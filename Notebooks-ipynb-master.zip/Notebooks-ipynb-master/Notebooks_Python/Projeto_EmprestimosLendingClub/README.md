## Projeto de Classificação de clientes
### Obs: Preview do projeto clicando no arquivo .ipynb


#### Será analisado dados reais de uma empresa americana de empréstimos chamada Lending Club. Lending club conecta pessoas que precisam de dinheiro(mutuários) com pessoas que têm dinheiro(investidores), porém, como investidor, você gostaria de investir em pessoas que mostraram um perfil de ter uma alta probabilidade de pagá-lo de volta. Será criado um modelo que ajude a prever isso.

## Informações adicionais:
# Modelo utilizado: 
#### Random Forest
#### Logistic Regression
#### Adaboost
#### Gradient Boosting
#### Extra Tree
#### SVM(SVC)
#### KNN

