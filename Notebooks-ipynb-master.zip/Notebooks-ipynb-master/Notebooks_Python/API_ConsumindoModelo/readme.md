# Resumo:
## Consumindo modelo
#### Foi criada uma api que puxa um modelo salvo numa máquina local, e através de um jupyter notebook recebe os dados de um dataset **de exemplo** alvo, e devolve o dataset junto com a predição da coluna informada.


## Informações adcionais:
#### Foi usado um dataset simples apenas com o intuito de consumir o modelo
#### dataset de exemplo: ranking de status dos pokemons de um jogo da franquia
#### Modelos utilizados: Random Forest, Gradient Boosting e AdaBoost para prever se o pokemon é lendário ou não


# **Atenção**
#### O aquivo .py só irá funcionar caso preencha os dados para localizar o modelo da maquina local

