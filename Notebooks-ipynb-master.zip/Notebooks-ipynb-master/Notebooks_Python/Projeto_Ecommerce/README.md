# Análise exploratória de um dataset de uma loja virtual de roupas
### Obs: Preview do projeto clicando no arquivo .ipynb

## Informações adicionais:
# Modelo utilizado: 
#### Linear Regression
#### Gradient Boosting
#### Extra Tree
#### Adaboost
#### Random Forest

