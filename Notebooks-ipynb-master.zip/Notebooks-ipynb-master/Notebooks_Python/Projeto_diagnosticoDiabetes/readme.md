# Projeto de Classificação de pacientes
### Obs: Preview do projeto clicando no arquivo .ipynb


#### Este projeto irá explorar brevemente os dados de um Hospital com possíveis pacientes diabéticos, assim sendo necessário criar modelos preditivos para auxiliar no diagnóstico dos futuros pacientes baseado no histórico dos pacientes já registrados

## Informações adicionais:
# Modelo utilizado: 
##### Random Forest
##### Logistic Regression
##### SVM(SVC)
##### AdaBoost
##### GradientBoosting
##### Extra Tree

